

<div class="container mt-5 ">
  <h2>Recipient List <a href="<?php echo e(url('food/view_foodItems')); ?>" class="btn btn-primary" >Back</a> <a href="add-recipient" class="btn btn-info" >Add Resipients</a></h2>
  
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Sr. No.</th>
        <th>Recipient Name</th>
        <th>Contact Info</th>
        <th>Food Items</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resipients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop->index+1); ?></td>
        <td><?php echo e($resipients->recipient_name); ?></td>
        <td><?php echo e($resipients->recipient_contact_info); ?></td>
        <td>
          <?php $foods = DB::table('food_items')->where(['id'=>$resipients->food_item_id])->first();?>
          <?php echo e($foods->food_name); ?>

        </td>
        <td>
          <a href="<?php echo e(route('delete-recipient', $resipients->id)); ?>" class="btn btn-danger btn-rounded waves-effect waves-light"> Delete</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlatableTest\resources\views/recipient/view_recipient.blade.php ENDPATH**/ ?>