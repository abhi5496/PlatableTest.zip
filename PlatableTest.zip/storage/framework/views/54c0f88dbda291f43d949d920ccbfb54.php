

<div class="container mt-5 ">
  <h2>Donor List <a href="<?php echo e(url('food/view_foodItems')); ?>" class="btn btn-primary" >Back</a> <a href="add-donor" class="btn btn-info" >Add Donor</a></h2>
  
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Sr. No.</th>
        <th>Donor Name</th>
        <th>Contact Info</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop->index+1); ?></td>
        <td><?php echo e($donor->donor_name); ?></td>
        <td><?php echo e($donor->donor_contact_info); ?></td>
        <td>
          <a href="<?php echo e(route('delete-donor',$donor->id)); ?>" class="btn btn-danger btn-rounded waves-effect waves-light"> Delete</a>
          <a href="<?php echo e(url('donor/view_doneted_foods/'.$donor->id)); ?>" class="btn btn-primary btn-rounded waves-effect waves-light">Doneted Food</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlatableTest\resources\views/donor/view_donor.blade.php ENDPATH**/ ?>