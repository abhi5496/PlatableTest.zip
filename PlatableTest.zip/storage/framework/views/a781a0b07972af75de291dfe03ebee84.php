
<div class="container">
   <h2>Add New Donor</h2>
   <div class="row">
      <div class="col-lg-6">
         <form action="<?php echo e(route('add_donor')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label class="form-label">Name</label>
            <input type="text" class="form-control" name="donor_name"/>
            <label class="form-label">Contact info</label>
            <input type="text" class="form-control" name="donor_contact_info"/><br/>
            <input type="submit" value="Submit" class="btn btn-primary" />
         </form>
      </div>
   </div>
</div>
</body>
<?php echo $__env->make('layouts.app'
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlatableTest\resources\views/donor/add_donor.blade.php ENDPATH**/ ?>