
<div class="container">
   <h2>Add New Recipient</h2>
   <div class="row">
      <div class="col-lg-6">
         <form action="<?php echo e(route('add_recipient')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label class="form-label">Name</label>
            <input type="text" class="form-control" name="recipient_name"/>
            <label class="form-label">Contact info</label>
            <input type="text" class="form-control" name="recipient_contact_info"/><br/>
            <label class="form-label">Select</label>
            <select class="form-control" name="food_item_id">
               <?php $foods = DB::table('food_items')->get();?>
               <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($value->id); ?>"><?php echo e($value->food_name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select><br/>
            <input type="submit" value="Submit" class="btn btn-primary" />
         </form>
      </div>
   </div>
</div>
</body>
<?php echo $__env->make('layouts.app'
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlatableTest\resources\views/recipient/add_recipient.blade.php ENDPATH**/ ?>