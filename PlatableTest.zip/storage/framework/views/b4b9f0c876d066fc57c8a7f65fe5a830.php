

<div class="container mt-5 ">
  <h2>Doneted Food list  <a href="<?php echo e(url('donor/view_donor')); ?>" class="btn btn-primary" >Back</a> 
      <a href="<?php echo e(url('donor/add-doneted-foods/'.$id)); ?>" class="btn btn-info" >Add Food</a></h2>
  
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Sr. No.</th>
        <th>Donor Name</th>
        <th>Donated food</th>
      </tr>
    </thead>
    <tbody>
        <?php $doneted_foods = DB::table('doneted_foods')->get();?>
        <?php $__currentLoopData = $doneted_foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doneted_food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td><?php echo e($doneted_food->donor_name); ?></td>
            <td><?php echo e($doneted_food->food_name); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlatableTest\resources\views/donor/view_doneted_foods.blade.php ENDPATH**/ ?>